INSTALLATION:

WinPython-64bit-3.6.3.0Qt5

Mandatory additional packages:
- Add ASTRA toolbox by coping the binaries into site-packages
- Add Tifffile via Python wheel


To enable GPU monitoring:
- CUDA Toolkit 8.0 required to have nvidia-smi
- Add to system PATH the following line: C:\Program Files\NVIDIA Corporation\NVSMI
- Add GpUtil with the command line: pip install gputil
