﻿import sys
import tifffile 
import h5py
import numpy as np
import math

import kst_core.kst_io as kst_io
import kst_core.kst_flat_fielding as kst_flat_fielding
import kst_core.kst_remove_outliers as kst_remove_outliers
import kst_core.kst_matrix_manipulation as kst_matrix_manipulation
import kst_core.kst_reconstruction as kst_reconstruction
import kst_core.kst_preprocessing as kst_preprocessing
import kst_core.kst_tigre_FDK as kst_tigre_FDK
import kst_core.kst_astra_TVRDART as kst_astra_TVRDART
from kstDataset import kstDataset

from PyQt5.QtWidgets import QWidget, QApplication
from PyQt5.QtCore import QTimer, QCoreApplication

#from kstImageViewer import kstImageViewer
#from VoxImagePanel import VoxImagePanel
#from VoxHDFViewer import VoxHDFViewer
#from VoxSidebar import VoxSidebar
#from VoxMainPanel import VoxMainPanel
from kstMainWindow import kstMainWindow


import copy
from tifffile import imread, imsave

class Redirect(object):
	""" Trivial class used to redirect print() command to a QT widget.
	"""
	def __init__(self, widget):
		""" Class constructor.
		"""
		self.wg = widget


	def write(self, text):
		""" Forwarding of a print() command.
		"""

        # Append without new line:
		self.wg.append(text)



if __name__ == '__neinnein__':   
	
	import astra
	#import SIRT
	from glob import glob

	in_path  = 'D:\\KEST\\05_17_18\\tomo_6652\\input4matlab\\'
	rec_path = 'D:\\KEST\\05_17_18\\tomo_6652\\recon_kest_sum10_720_filt\\'   
	out_path = 'D:\\KEST\\05_17_18\\tomo_6652\\input4matlab_tvr-dart\\'

	ssd = 200.0 # Source-to-sample distance [mm]
	sdd = 50.0  # Sample-to-detector distance [mm]
	px  = 0.062 # pixsize [mm]

	offset_u = -3.0 # Offset for center of rotation
	offset_v = 40;  #
	rot_angles = 21.0 # deg

    ## Code
    # mkdir(OUT_PATH);

	magn   = (ssd + sdd) / ssd
	vol_px = px / magn

	# Read folder and first image to understand sizes:
	files = sorted(glob(in_path + '*.tif*'))
	nr_proj = len(files)

	im = imread(files[0]).astype(np.float32) 
	det_row = im.shape[0]
	det_col = im.shape[1]
	Nan = nr_proj

	data = np.zeros((det_row, det_col, nr_proj), np.float32)

	for i in range(nr_proj):
	
		# Read uncorrected tomo:
		tomo = imread(files[i]).astype(np.float32) 
			
		# Center of rotation:
		tomo = np.roll(tomo,round(offset_u),axis=1)
		tomo = np.roll(tomo,round(offset_v),axis=0)
	
		# Fill volume:	
		data[:,:,i] = tomo


	# Permute to match ASTRA data organization:
	data = np.transpose(data,(2,1,0))

	# Create output geometry (voxelsize = 1, everything should be rescaled):
	vol_geom = astra.create_vol_geom(det_col, det_col, det_row)

    # Create projection geometry:
	# Parameters: width of detector column, height of detector row, #rows, 
	# #columns, angles, distance source-origin, distance origin-detector
	angles = np.linspace(-180 - rot_angles,180 - rot_angles,Nan,True) * (np.pi / 180)
	proj_geom = astra.create_proj_geom('cone', px/vol_px, px/vol_px, det_row, det_col, angles, ssd/vol_px, sdd/vol_px)
	proj_id = astra.create_projector('cuda3d',proj_geom,vol_geom)  
	W = astra.OpTomo(proj_id)

	# Configuration of TVR-DART parameters
	Ngv = 2 # number of material composition in the specimen (including vacuum)
	K = 4*np.ones(Ngv-1) # sharpness of soft segmentation function
	lamb = 10 # weight of TV
	Niter = 50 # number of iterations

	## Initial reconstruction and normalization
	#print('Initial reconstruction...')
	#recsirt = kst_astra_TVRDART.SIRT_recon(data, 50, proj_geom, vol_geom, 'cuda')
	#sf = np.max(recsirt)
	#data = data/sf
	#recsirt = recsirt/sf

	# Read folder and first image to understand sizes:
	rec_files = sorted(glob(rec_path + '*.tif*'))
	nr_slices = len(rec_files)

	im = imread(rec_files[0]).astype(np.float32) 
	x = im.shape[0]
	y = im.shape[1]

	recsirt = np.zeros((x, y, nr_slices), np.float32)

	for i in range(nr_slices):
	
		# Read uncorrected tomo:
		slice = imread(rec_files[i]).astype(np.float32) 
	
		# Fill volume:	
		recsirt[:,:,i] = slice

	
	## Automatic parameter estimation
	#print('Parameter estimation...')
	yrange = [50,51]
	x0_esti = recsirt[:,yrange[0]:yrange[1]+1,:]
	data_esti = data[:,:,yrange[0]:yrange[1]+1]
	p_esti = data_esti.reshape(Nan*det_col*(yrange[1]-yrange[0]+1))
	gv = np.linspace(0, 1, Ngv,True)
	param0 = kst_astra_TVRDART.gv2param(gv,K)
	Segrec,param_esti = kst_astra_TVRDART.joint(W, p_esti, x0_esti, param0 ,lamb)
	[gv,K] = kst_astra_TVRDART.param2gv(param_esti)

	# Reconstruction with estimated parameters
	print('Reconstruction with estimated parameters...')
	p = data.reshape(Nan*Ndetx*Ndety)
	Segrec,rec = kst_astra_TVRDART.recon(W,p, recsirt, param_esti, lamb, Niter)
	gv = gv*sf
	Segrec = Segrec*sf

	# Save reconstruction
	print('Saving results...')
	imsave(out_path + 'recsirt_' + str(Nan).zfill(3) + '_proj_K=' + str(origK) + '_' + str(i).zfill(3) + '_' + "{:0.3f}".format(param_esti[0]) + '_' + "{:0.3f}".format(param_esti[1]) + '.tif', recsirt.astype(np.float32))
	imsave(out_path + 'segrec_' + str(Nan).zfill(3) + '_proj_K=' + str(origK) + '_' + str(i).zfill(3) + '_' + "{:0.3f}".format(param_esti[0]) + '_' + "{:0.3f}".format(param_esti[1]) + '.tif', Segrec.astype(np.float32))
	imsave(out_path + 'rec_' + str(Nan).zfill(3) + '_proj_K=' + str(origK) + '_' + str(i).zfill(3) + '_' + "{:0.3f}".format(param_esti[0]) + '_' + "{:0.3f}".format(param_esti[1]) + '.tif', rec.astype(np.float32))



if __name__ == '__nomain__':   
	
	import astra
	from glob import glob

	in_path = 'D:\\KEST\\'
	out_path = 'D:\\KEST\\Pipette_TuboOxford\\recon_kest_sum10_filt_tvr-dart\\'    

	slices = sorted(glob(in_path + '*.tif*'))
	num_files = len(slices)

	for i in range(0,1):
		for Nan_i in [24,16,12,8,4,2,1]: 

			rec = imread(slices[i]).astype(np.float32)
			[foo,Ndetx] = rec.shape
			Nan = 721
			angles = np.linspace(-180,180,Nan,True) * (np.pi / 180)
	
			# Create parallel beam sinogram:
			print('Configure projection and volume geometry with ' + str(Nan_i) + ' angles...')
			proj_geom = astra.create_proj_geom('parallel', 1.0, Ndetx, angles)
			vol_geom = astra.create_vol_geom(Ndetx,Ndetx)
			proj_id = astra.create_projector('cuda',proj_geom,vol_geom)
			W = astra.OpTomo(proj_id)
			data = W * rec
			data = np.reshape(data, (Nan, Ndetx))
			imsave('D:\\Temp\\sino_fwd.tif', data.astype(np.float32))

            # Decimate sinogram and re-create the geometry:
			data = data [::Nan_i,:]
			imsave('D:\\Temp\\sino_fwd_Nan_i.tif', data.astype(np.float32))
			[ang,Ndetx] = data.shape 
			angles = np.linspace(-180,180,ang,True) * (np.pi / 180)	
			proj_geom = astra.create_proj_geom('parallel', 1.0, Ndetx, angles)
			vol_geom = astra.create_vol_geom(Ndetx,Ndetx)
			proj_id = astra.create_projector('cuda',proj_geom,vol_geom)
			W = astra.OpTomo(proj_id)			

			## Intensity-offset correction
			##print('Intensity-offset correction...')
			##offset = 0.01
			##data += offset
			#data[data < 0.001] = 0.001
			#data = data / np.amax(data)

			# Configuration of TVR-DART parameters
			Ngv = 2 # number of material composition in the specimen (including vacuum, so at least two?????)
	
            # From the paper:
			# The choice of the transition constant K is less influenced by the data. While a lower value of
			# K makes the segmentation function too smooth by offering not enough push to the discrete gray 
            # values, setting the value too high pushes the solution too fast toward discrete values
		
			K = 6 * np.ones(Ngv - 1) # sharpness of soft segmentation function

			# As expected, the optimum choice of λ increases with higher noise level in the
			# projection data. For data with a relatively small amount of noise, a value range of λ ∈
			# [10,20] gives the optimal results while a higher value of λ ∈ [50,100] is needed for 
            # extremely noisy conditions
			lamb = 20 # weight of TV (do not affect much)
			Niter = 500 # number of iterations

			# Initial reconstruction and normalization
			print('Initial reconstruction of data having shape ' + str(data.shape) + '...')
			recsirt = kst_astra_TVRDART.SIRT_recon(data, Niter, proj_geom, vol_geom,'cuda')
			sf = np.max(recsirt)
			data = data / sf
			p = data.reshape(ang * Ndetx)
			rec = rec / sf
	
			# Automatic parameter estimation
			print('Parameter estimation...')
			gv = np.linspace(0, 1, Ngv,True)
			param0 = kst_astra_TVRDART.gv2param(gv,K)
			Segrec,param_esti = kst_astra_TVRDART.joint(W, p, recsirt, param0 ,lamb)
			[gv,Z] = kst_astra_TVRDART.param2gv(param_esti)

			# Reconstruction with estimated parameters
			Segrec,rec = kst_astra_TVRDART.recon(W, p, recsirt, param_esti, lamb, Niter)

            # Output:
			imsave(out_path + 'recsirt_' + str(ang).zfill(3) + '_proj_K=' + str(K[0]) + '_' + str(i).zfill(3) + '_' + "{:0.3f}".format(param_esti[0]) + '_' + "{:0.3f}".format(param_esti[1]) + '.tif', recsirt.astype(np.float32))
			imsave(out_path + 'slice_' + str(ang).zfill(3) + '_proj_K=' + str(K[0]) + '_' + str(i).zfill(3) + '_' + "{:0.3f}".format(param_esti[0]) + '_' + "{:0.3f}".format(param_esti[1]) + '.tif', Segrec.astype(np.float32))
			imsave(out_path + 'rec_' + str(ang).zfill(3) + '_proj_K=' + str(K[0]) + '_' + str(i).zfill(3) + '_' + "{:0.3f}".format(param_esti[0]) + '_' + "{:0.3f}".format(param_esti[1]) + '.tif', rec.astype(np.float32))



if __name__ == '__main__':

	# Create the application:
	app = QApplication(sys.argv)

	# Define application details:
	QCoreApplication.setOrganizationName("INFN")
	QCoreApplication.setApplicationName("KEST Recon")

	# Init main window:
	mainWindow = kstMainWindow()

	# Redirect print() and errors:
	sys.stdout = Redirect(mainWindow.mainPanel.log.outputLog)
	sys.stderr = Redirect(mainWindow.mainPanel.log.errorLog)

	# Run application:
	mainWindow.show()
	t = QTimer()
	t.singleShot(0,mainWindow.onQApplicationStarted)
	sys.exit(app.exec_())
